let quote = document.getElementById("quo");
let auth = document.getElementById("aut");

function getQuotes() {

    fetch("https://api.quotable.io/random")
        .then((response) =>
            response.json()
        )
        .then((data) => {

            quote.innerHTML = data.content;
            auth.innerHTML = data.author;
            // console.log(data.author);


        })
        .catch((error) => {
            console.log(error);
        });
}